<?php

namespace Intervention\Image\Exception;

class MissingDependencyException extends ImageException
{
    # nothing to override
}
