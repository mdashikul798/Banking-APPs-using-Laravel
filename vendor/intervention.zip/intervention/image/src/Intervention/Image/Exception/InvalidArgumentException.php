<?php

namespace Intervention\Image\Exception;

class InvalidArgumentException extends ImageException
{
    # nothing to override
}
